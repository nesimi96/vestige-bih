self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d61c78965270c402ae08717cc678d737",
    "url": "/index.html"
  },
  {
    "revision": "c8c8e6d4f4d034e05684",
    "url": "/static/css/main.8e76b344.chunk.css"
  },
  {
    "revision": "88336ff71eb4c9a7b686",
    "url": "/static/js/2.ba10209d.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/static/js/2.ba10209d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4b0bb37ec8f52948390e",
    "url": "/static/js/3.3f5151a0.chunk.js"
  },
  {
    "revision": "efcb2da9e52cb85b9d45",
    "url": "/static/js/4.b125b372.chunk.js"
  },
  {
    "revision": "c8c8e6d4f4d034e05684",
    "url": "/static/js/main.7e72d025.chunk.js"
  },
  {
    "revision": "050fc0e5cea1a9433e98",
    "url": "/static/js/runtime-main.f6490cf1.js"
  },
  {
    "revision": "4ee8687af4d7d359b205bc6e489dd22b",
    "url": "/static/media/212-sexy-men-probador-big.4ee8687a.png"
  },
  {
    "revision": "63c28296fa1cdcf38aebe9b251d11876",
    "url": "/static/media/212-vip-for-her-big.63c28296.png"
  },
  {
    "revision": "ee2591e65d5663786b0101f123318552",
    "url": "/static/media/212-vip-men-big.ee2591e6.png"
  },
  {
    "revision": "280627605d11e8db24c9238d53be1acb",
    "url": "/static/media/Neutra-Text-Alt_32104.28062760.ttf"
  },
  {
    "revision": "dde34190bd7349cd2caf363114dd62dd",
    "url": "/static/media/about.dde34190.jpg"
  },
  {
    "revision": "55f76c3c27186e4ee8118162be55dfd8",
    "url": "/static/media/atomizer-1.55f76c3c.jpg"
  },
  {
    "revision": "cfd72958cecc4fd08137496e4e16f6ff",
    "url": "/static/media/atomizer-2.cfd72958.jpg"
  },
  {
    "revision": "506476051f9498b1662622115fed1cbc",
    "url": "/static/media/atomizer-3.50647605.jpg"
  },
  {
    "revision": "247e1e257ad7bbe19a36b42b4b65a392",
    "url": "/static/media/azzarowanted.247e1e25.png"
  },
  {
    "revision": "e5af7f3d272ade72b01a817ed975c226",
    "url": "/static/media/bacarat-removebg-preview.e5af7f3d.png"
  },
  {
    "revision": "ae6212385024b8067858ef67438a82e6",
    "url": "/static/media/bluelabel.ae621238.png"
  },
  {
    "revision": "c5cc313de2a59eb7e069732296bcf017",
    "url": "/static/media/bombshell.c5cc313d.png"
  },
  {
    "revision": "b27f32ca7678c397e41f79cc1cfe4b14",
    "url": "/static/media/bosnia-flag.b27f32ca.png"
  },
  {
    "revision": "bd2f6c1249c329f44f0cf4761c8229a7",
    "url": "/static/media/burberry-body-big.bd2f6c12.png"
  },
  {
    "revision": "c98372307bf4fe811f496800610c22f1",
    "url": "/static/media/burberry-my-burberry-black-big.c9837230.png"
  },
  {
    "revision": "c36a17e55bfb37f5119dca37787cac82",
    "url": "/static/media/burberry-my-burberry-women-big.c36a17e5.png"
  },
  {
    "revision": "0e2823bf1d339072a3d127e1be25916e",
    "url": "/static/media/burberry.0e2823bf.jpg"
  },
  {
    "revision": "29116bbb05e19347e6f20857db42ae66",
    "url": "/static/media/bvlgari-aqua-pour-homme-big.29116bbb.png"
  },
  {
    "revision": "416ba647fce3c06c8a72e190960e9e95",
    "url": "/static/media/bvlgari-goldea-big.416ba647.png"
  },
  {
    "revision": "198c2b15ad9321315fb4931946eaca3e",
    "url": "/static/media/bvlgari-jasmin-noir-big.198c2b15.png"
  },
  {
    "revision": "1fd9ef935dd06b747c1a3f3bfaa81d8b",
    "url": "/static/media/bvlgari-man-in-black-big.1fd9ef93.png"
  },
  {
    "revision": "d96eae5a7f84d72c7eeb22204229cf50",
    "url": "/static/media/bvlgari-omnia-amethyste-big.d96eae5a.png"
  },
  {
    "revision": "3cd717ce240bd85b57a78ea2af104132",
    "url": "/static/media/bvlgari-omnia-coral-big.3cd717ce.png"
  },
  {
    "revision": "afdc907e2cc85d5ad3326efaa80a1ed2",
    "url": "/static/media/bvlgari-omnia-crystalline-big.afdc907e.png"
  },
  {
    "revision": "692659555782d1437b8e332080ef6105",
    "url": "/static/media/bvlgari-omnia-green-jade-big.69265955.png"
  },
  {
    "revision": "f3c18e81a9637664ad5485e036db3f34",
    "url": "/static/media/bvlgari.f3c18e81.jpg"
  },
  {
    "revision": "24c2abdedf1a9a820e80a012548157cc",
    "url": "/static/media/calvin-klein-euphoria-men-big.24c2abde.png"
  },
  {
    "revision": "93053a153e75181ed0c5e7bf8637f7ed",
    "url": "/static/media/calvin-klein-euphoria-women-big.93053a15.png"
  },
  {
    "revision": "7a3c33276260e93225dc71e5124fdf04",
    "url": "/static/media/calvin-klein.7a3c3327.jpg"
  },
  {
    "revision": "3351c75327cc826541b3fe5a27700f61",
    "url": "/static/media/carolina-herrera-good-girl-bad-body-big.3351c753.png"
  },
  {
    "revision": "4650c052a56ad5fef852be11fe095d4d",
    "url": "/static/media/carolina-herrera-good-girl-big.4650c052.png"
  },
  {
    "revision": "0681f405cda538b5748e37ea52cd1802",
    "url": "/static/media/carolina-herrera-good-girl-collector-edition-big.0681f405.png"
  },
  {
    "revision": "d6527fbbf715ce53cfcba146d2b9c97d",
    "url": "/static/media/carolina-herrera-good-girl-glorious-gold-big.d6527fbb.png"
  },
  {
    "revision": "856db16a3e7f56758a0af292bf577e49",
    "url": "/static/media/carolina-herrera-its-good-to-be-bad-big.856db16a.png"
  },
  {
    "revision": "43db7592cd2c7d8f8f9b3a374619d658",
    "url": "/static/media/carolina-herrera-sexy-man-big.43db7592.png"
  },
  {
    "revision": "b445dd1b8241867bfbcc816a9ca89c45",
    "url": "/static/media/carolina-herrera.b445dd1b.jpg"
  },
  {
    "revision": "8feaa3d292b1d4b6a6304f48385903ec",
    "url": "/static/media/chanel-allure-big.8feaa3d2.png"
  },
  {
    "revision": "850b16b41aa8dc72808141be9337a601",
    "url": "/static/media/chanel-allure-homme-sport-big.850b16b4.png"
  },
  {
    "revision": "6d1d2072c14403b37db63e69adbed599",
    "url": "/static/media/chanel-bleu-de-chanel-big.6d1d2072.png"
  },
  {
    "revision": "ce37282576225e7c119fea4228c588e5",
    "url": "/static/media/chanel-chance-big.ce372825.png"
  },
  {
    "revision": "e481485972a0ffb65c82b84ff9c90741",
    "url": "/static/media/chanel-coco-noir-big.e4814859.png"
  },
  {
    "revision": "18913c5ac17034eb7dd9cd9cd64d816c",
    "url": "/static/media/chanel-gabrielle-big.18913c5a.png"
  },
  {
    "revision": "278ac26da5e85e02ec2956149338211a",
    "url": "/static/media/chanel-mademoiselle-big.278ac26d.png"
  },
  {
    "revision": "c04614cbb091f01302cb9f6599f0f4a6",
    "url": "/static/media/chanel-n-5-big.c04614cb.png"
  },
  {
    "revision": "74b24f0ed3747916933002bcfc723708",
    "url": "/static/media/chanel.74b24f0e.jpg"
  },
  {
    "revision": "df5b98869ead724f2e76633955fe895f",
    "url": "/static/media/chanelallureforher.df5b9886.png"
  },
  {
    "revision": "2dc9bd65df0ea1ad7283204ce55c12ab",
    "url": "/static/media/chloe-fleur-big.2dc9bd65.png"
  },
  {
    "revision": "7e8b62818372ff515324a7b6811f95e6",
    "url": "/static/media/chloe-nomade-big.7e8b6281.png"
  },
  {
    "revision": "6a931b890aa8ccfe6d87496d0f6ca7de",
    "url": "/static/media/chloe.6a931b89.jpg"
  },
  {
    "revision": "1c3d628d9de8e387dcd2e3ee93653798",
    "url": "/static/media/christian-dior-addict-big.1c3d628d.png"
  },
  {
    "revision": "2511eb5013b964a35d59a7cd622ef046",
    "url": "/static/media/christian-dior-fahrenheit-big.2511eb50.png"
  },
  {
    "revision": "33a4c2ac520ddfd5344d6494aa9dc724",
    "url": "/static/media/christian-dior-homme-intese-big.33a4c2ac.png"
  },
  {
    "revision": "bfd4a28794b104b23c3f9057c205059e",
    "url": "/static/media/christian-dior-hypnotic-poison-big.bfd4a287.png"
  },
  {
    "revision": "49cefaefad98e8f463966587cfa1227f",
    "url": "/static/media/christian-dior-jadore-big.49cefaef.png"
  },
  {
    "revision": "b366e23a64c5520b01d620a5bb995cb2",
    "url": "/static/media/christian-dior-joy-big.b366e23a.png"
  },
  {
    "revision": "ab6c54d3ec2b8efbabdca6bd14bcdcc3",
    "url": "/static/media/christian-dior-miss-dior-big.ab6c54d3.png"
  },
  {
    "revision": "23a8440b878bb373a67dece224920ab4",
    "url": "/static/media/christian-dior-sauvage-big.23a8440b.png"
  },
  {
    "revision": "b51090519172e31a55c55b9a184cbd51",
    "url": "/static/media/christian-dior.b5109051.jpg"
  },
  {
    "revision": "9578bc6e96753a9cec406faabca16534",
    "url": "/static/media/creed-aventus-big.9578bc6e.png"
  },
  {
    "revision": "50f22db12d090bc02477e1fe394c4bb4",
    "url": "/static/media/creed.50f22db1.jpg"
  },
  {
    "revision": "1adca0a690f2e1c6c533676e8f1ac2c7",
    "url": "/static/media/creedforher.1adca0a6.png"
  },
  {
    "revision": "f356a4e992db15754aef0feba904f7db",
    "url": "/static/media/davidoff-cool-water-big.f356a4e9.png"
  },
  {
    "revision": "74bb549a1391e9f580d7a60667bc2537",
    "url": "/static/media/davidoff.74bb549a.jpg"
  },
  {
    "revision": "eeed52a1fc35b43d466a028e066c9ebc",
    "url": "/static/media/diesel-bad-big.eeed52a1.png"
  },
  {
    "revision": "ff0374fc12f3012898a9993c71816679",
    "url": "/static/media/diesel.ff0374fc.jpg"
  },
  {
    "revision": "70e01316c7c05c8df8ba8e1fa98c0f1e",
    "url": "/static/media/dior-homme.70e01316.png"
  },
  {
    "revision": "e2babd59e3a850e0bfef0ef3c0d90e1e",
    "url": "/static/media/dior-poison.e2babd59.jpg"
  },
  {
    "revision": "cadb9a6e9ebb0d6b30664598ac648465",
    "url": "/static/media/dolce&gabanna.cadb9a6e.jpg"
  },
  {
    "revision": "d8eb20211d6d57b2bdadd5c0fd7c95c8",
    "url": "/static/media/dolce&gabbana-k-by-dolce&gabbana-big.d8eb2021.png"
  },
  {
    "revision": "9a5731956c87f9deb75abd548bbda61b",
    "url": "/static/media/dolce&gabbana-light-blue-big.9a573195.png"
  },
  {
    "revision": "9dc3e844f1ed13973614c3c8bf099820",
    "url": "/static/media/dolce&gabbana-the-one-big.9dc3e844.png"
  },
  {
    "revision": "df510dba87d07b0d8d7c5fa8213d6721",
    "url": "/static/media/dylanblue.df510dba.png"
  },
  {
    "revision": "fe18c56517cd2591cc8df7347834b546",
    "url": "/static/media/eau-fraiche.fe18c565.png"
  },
  {
    "revision": "2ec1cb4ad8037dc885ff9a3d287a1df7",
    "url": "/static/media/eau-tendre.2ec1cb4a.png"
  },
  {
    "revision": "1e61810d03643c60ed495c062b31b65e",
    "url": "/static/media/emporio-armani-stronger-with-you-big.1e61810d.png"
  },
  {
    "revision": "5fb103d8a5ea2059902c5ceff1335f40",
    "url": "/static/media/flowerbomb.5fb103d8.png"
  },
  {
    "revision": "daf1921f63d9decd1cab613b6ac9d0c1",
    "url": "/static/media/giorgio-armani-acqua-di-gioa-big.daf1921f.png"
  },
  {
    "revision": "152cae4112ef9662d23ad7f274b1e3e0",
    "url": "/static/media/giorgio-armani-acqua-di-gioa-women-big.152cae41.png"
  },
  {
    "revision": "c8f614e2eed1cc994f2e74802c3595ac",
    "url": "/static/media/giorgio-armani-aqua-di-gioa-profumo.c8f614e2.png"
  },
  {
    "revision": "0ff634af96098020f32b32be92cc81d9",
    "url": "/static/media/giorgio-armani-black-code-big.0ff634af.png"
  },
  {
    "revision": "bd0ab958c7d0ca0fdf17d621cb666c91",
    "url": "/static/media/giorgio-armani-code-big.bd0ab958.png"
  },
  {
    "revision": "02df5cfdc232c2f95751c4df78b974d1",
    "url": "/static/media/giorgio-armani-code-for-women-big.02df5cfd.png"
  },
  {
    "revision": "b22ec61ca990f3c1b52b48d52d6bbd78",
    "url": "/static/media/giorgio-armani-prive-ambre-orient-big.b22ec61c.png"
  },
  {
    "revision": "b3862f5adda79c216a53a1c9c2e0a27c",
    "url": "/static/media/giorgio-armani-si-intese-big.b3862f5a.png"
  },
  {
    "revision": "b49e9672eab2723dabc76e4da9c742a1",
    "url": "/static/media/giorgio-armani-si-passione-big.b49e9672.png"
  },
  {
    "revision": "c4800168f0893c1fc7c757325ff0710a",
    "url": "/static/media/giorgio-armani-si-women-big.c4800168.png"
  },
  {
    "revision": "e4da8764150e277c4bc39b1565870f03",
    "url": "/static/media/giorgio-armani.e4da8764.jpg"
  },
  {
    "revision": "26f65457475fab445c56a58a3f5b9e92",
    "url": "/static/media/givenchy-ange-ou-demon-big.26f65457.png"
  },
  {
    "revision": "5480c369da0be76ef77fc9e2e274c53c",
    "url": "/static/media/givenchy-l'interdit-big.5480c369.png"
  },
  {
    "revision": "f1f0e8ff0536e1261745ef825d49a27a",
    "url": "/static/media/givenchy-pi-big.f1f0e8ff.png"
  },
  {
    "revision": "5dc3d444caa3f52bb1270e986f482e91",
    "url": "/static/media/givenchy.5dc3d444.jpg"
  },
  {
    "revision": "dcac4727140e492cae5f6229c4c10fdb",
    "url": "/static/media/gucci-bamboo-big.dcac4727.png"
  },
  {
    "revision": "6e0124f7e2303a8ab8819ada226a37dd",
    "url": "/static/media/gucci-bloom-big.6e0124f7.png"
  },
  {
    "revision": "6f479699de279cf7829101e6ef2031fa",
    "url": "/static/media/gucci-guilty-big.6f479699.png"
  },
  {
    "revision": "9dd177f132af4cc17523b22d3c050bb6",
    "url": "/static/media/gucci-rush-big.9dd177f1.png"
  },
  {
    "revision": "ac240d57cda8ae5dbaf170df035dc999",
    "url": "/static/media/gucci.ac240d57.jpg"
  },
  {
    "revision": "7a619fdbae312ac89826046784fa6186",
    "url": "/static/media/gucciflora.7a619fdb.png"
  },
  {
    "revision": "424ac7bee5760958e95c78f20aaa53ec",
    "url": "/static/media/header-background.424ac7be.jpg"
  },
  {
    "revision": "95528d3d954976c4eb18c4a5d9869d7b",
    "url": "/static/media/hugo-boss-bottled-big.95528d3d.png"
  },
  {
    "revision": "1cee2793e66bc93110e8f186e52a07c4",
    "url": "/static/media/hugo-boss-bottled-night-big.1cee2793.png"
  },
  {
    "revision": "f92ec8df6ad63c3912f6156ea0fc82f1",
    "url": "/static/media/hugo-boss-dark-blue-big.f92ec8df.png"
  },
  {
    "revision": "18c31899c3df2faf05e81e89346f8e84",
    "url": "/static/media/hugo-boss-just-different-big.18c31899.png"
  },
  {
    "revision": "27d43cbb15b8f7207101ff1ea641f5e6",
    "url": "/static/media/hugo-boss-the-scent-big.27d43cbb.jpg"
  },
  {
    "revision": "2aa9b1044cfd1af3d6aa5db7752eebb7",
    "url": "/static/media/hugo-boss-the-scent-big.2aa9b104.png"
  },
  {
    "revision": "b8c34eb066eb261a16a3c8fe01a51b27",
    "url": "/static/media/hugo-boss-the-scent-for-her-big.b8c34eb0.png"
  },
  {
    "revision": "f1546cd53ca35c7e503c5907d2635e99",
    "url": "/static/media/hugo-boss.f1546cd5.jpg"
  },
  {
    "revision": "895908cb0084f3b3e9f117946cdfa9ca",
    "url": "/static/media/jean-paul-gaultier-classique-big.895908cb.png"
  },
  {
    "revision": "89dc0809e8be09e88e74447cb5c3a965",
    "url": "/static/media/jean-paul-gaultier-le-male-big.89dc0809.png"
  },
  {
    "revision": "ff02d50a4462f60573a77a79a1ed1854",
    "url": "/static/media/jean-paul-gaultier-scandal-big.ff02d50a.png"
  },
  {
    "revision": "fde59ad26e67cfec66a61c62cb64698f",
    "url": "/static/media/joop-homme-big.fde59ad2.png"
  },
  {
    "revision": "1d147ea5bbad62d1332d17d6087b48d5",
    "url": "/static/media/joop.1d147ea5.jpg"
  },
  {
    "revision": "9d865d919d54eea4bbcf4a3984ce2e00",
    "url": "/static/media/jpg.9d865d91.jpg"
  },
  {
    "revision": "23614841335c5f05fa538a6a481c98f3",
    "url": "/static/media/l'imperatice.23614841.png"
  },
  {
    "revision": "ea4bd2e60cc7ec100c4fc2c556b02621",
    "url": "/static/media/lancome-hypnose-big.ea4bd2e6.png"
  },
  {
    "revision": "a76629203895afa4cf159da6382c083c",
    "url": "/static/media/lancome-la-nuit-tresor-a-la-folie-big.a7662920.png"
  },
  {
    "revision": "141f02fbcec1d0ed5c6bfb565d304360",
    "url": "/static/media/lancome-la-vie-est-belle-big.141f02fb.png"
  },
  {
    "revision": "76b27a097a660dc00303ac78d17b3fa4",
    "url": "/static/media/lancome-tresor-big.76b27a09.png"
  },
  {
    "revision": "4bfd15fa7b08f2dd538f9257c292f551",
    "url": "/static/media/lancome.4bfd15fa.jpg"
  },
  {
    "revision": "a9ab81dc535ab7adeeea840aea000f2b",
    "url": "/static/media/light-blue-women.a9ab81dc.png"
  },
  {
    "revision": "220aae2eb1f546ba9719bc5be896e05f",
    "url": "/static/media/lightblue.220aae2e.jpg"
  },
  {
    "revision": "0cd12ca0caac53a1a257bbc9b5799d32",
    "url": "/static/media/lost-cherry.0cd12ca0.png"
  },
  {
    "revision": "62b61676723e620d91be6ee396b16c8d",
    "url": "/static/media/marc-jacobs-decadence-big.62b61676.png"
  },
  {
    "revision": "58d0e43cb850a4481df81e232fde3742",
    "url": "/static/media/marc-jacobs.58d0e43c.jpg"
  },
  {
    "revision": "80bf6fddd7085313541926a7cf6a0e47",
    "url": "/static/media/men-preview.80bf6fdd.jpg"
  },
  {
    "revision": "2bb676c5233ef664eb05164b06a926d1",
    "url": "/static/media/miss-dior.2bb676c5.png"
  },
  {
    "revision": "c4dd5a69cf70a51e3c50f78cd55475c8",
    "url": "/static/media/mon-guerlain.c4dd5a69.png"
  },
  {
    "revision": "4aaf26555dcd3d6925052864867bae28",
    "url": "/static/media/my-way.4aaf2655.png"
  },
  {
    "revision": "bd5d2570fb6d662c9893a9f3da5ffaed",
    "url": "/static/media/narciso-rodriguez-for-her-big.bd5d2570.png"
  },
  {
    "revision": "c3bd02c4bca0c9130e7566aa249bc937",
    "url": "/static/media/narciso-rodriguez-poudree-big.c3bd02c4.png"
  },
  {
    "revision": "c0daf15cf5a10c7856d23baee5f35d96",
    "url": "/static/media/narciso-rodriguez.c0daf15c.jpg"
  },
  {
    "revision": "47ea516d7d6524ce34eeb3c7d0d3270e",
    "url": "/static/media/narciso-rouge.47ea516d.png"
  },
  {
    "revision": "b1ac791181bd5baf47749ef7ffbdc0f6",
    "url": "/static/media/nina-ricci.b1ac7911.png"
  },
  {
    "revision": "6608476da50ce17d85b632d1686a5f72",
    "url": "/static/media/omnia-crystalline-big.6608476d.png"
  },
  {
    "revision": "fb1101e056f3fcf58c4ee34528c7c59a",
    "url": "/static/media/only-the-brave.fb1101e0.png"
  },
  {
    "revision": "6234b6a5ce3478eb8d8b31adeaeaca3f",
    "url": "/static/media/our-first-add.6234b6a5.jpg"
  },
  {
    "revision": "f1f5f2284dd1cb54419ff8ace87243e2",
    "url": "/static/media/paco-rabanne-black-xs-big.f1f5f228.png"
  },
  {
    "revision": "27ae6f184053127de16231092eca7745",
    "url": "/static/media/paco-rabanne-invictus-big.27ae6f18.png"
  },
  {
    "revision": "d56b4e20d8ebf628e67b1a91cbb09262",
    "url": "/static/media/paco-rabanne-lady-million-big.d56b4e20.png"
  },
  {
    "revision": "0ecf23da639ad3f4fc5f7d1181ff3b1a",
    "url": "/static/media/paco-rabanne-lady-million-prive-big.0ecf23da.png"
  },
  {
    "revision": "d58955ddc4672a168852f9d63170cc71",
    "url": "/static/media/paco-rabanne-olympea-big.d58955dd.png"
  },
  {
    "revision": "264272262fada5473e48d227e1f08143",
    "url": "/static/media/paco-rabanne-one-million-big.26427226.png"
  },
  {
    "revision": "bf585e9b4bccafdb7e75ba49e888b3b9",
    "url": "/static/media/paco-rabanne-one-million-prive-big.bf585e9b.png"
  },
  {
    "revision": "71a062f8d32663cabe998582e76c3a18",
    "url": "/static/media/paco-rabanne-pure-excess-big.71a062f8.png"
  },
  {
    "revision": "f4ce6d31414133320a11140a82989ddc",
    "url": "/static/media/paco-rabanne-ultraviolet-man-big.f4ce6d31.png"
  },
  {
    "revision": "10c9fc04fd232ea7d6ac98c30de08b72",
    "url": "/static/media/paco-rabanne.10c9fc04.jpg"
  },
  {
    "revision": "6e97979ddbdfabe6b333d9d0b8648c0e",
    "url": "/static/media/pour-femme-intense-big.6e97979d.png"
  },
  {
    "revision": "af6c522396423eb2ea0282fe56a0d360",
    "url": "/static/media/roberto-cavalli-uomo-big.af6c5223.png"
  },
  {
    "revision": "70b5f3ba3e2159030fade69e3a38af96",
    "url": "/static/media/roberto-cavalli-women-big.70b5f3ba.png"
  },
  {
    "revision": "02a0f17d2862a08efeb19de1653b6a75",
    "url": "/static/media/roberto-cavalli.02a0f17d.jpg"
  },
  {
    "revision": "2a71ccb175e16ea07e6ea08e0e50cc99",
    "url": "/static/media/rose-prick.2a71ccb1.png"
  },
  {
    "revision": "949c17e2957439e1786c93013afb62c5",
    "url": "/static/media/serbia-flag.949c17e2.png"
  },
  {
    "revision": "cfc28a52e56136e021a32f4305e1ef00",
    "url": "/static/media/sheisedo-zen.cfc28a52.png"
  },
  {
    "revision": "1f3f3ccf88581812cce6729240998edd",
    "url": "/static/media/sospiroopera.1f3f3ccf.png"
  },
  {
    "revision": "2e671849575ab187a3f089afaea74e82",
    "url": "/static/media/terre-d-hermes.2e671849.png"
  },
  {
    "revision": "e561ce0b37fb687836708088b48e0495",
    "url": "/static/media/the-one-women.e561ce0b.png"
  },
  {
    "revision": "e4ce7483702f8f4d187712829ecd83c6",
    "url": "/static/media/thierry-mugler-alien-big.e4ce7483.png"
  },
  {
    "revision": "4b6af1233d18f415881164771e9421a6",
    "url": "/static/media/thierry-mugler-angel.4b6af123.png"
  },
  {
    "revision": "e1f3ca065a3c859d269526bfac39bacc",
    "url": "/static/media/thierry-mugler-aura-mugler-big.e1f3ca06.png"
  },
  {
    "revision": "5096ca23ddaab206739fc3b6d930a350",
    "url": "/static/media/thiery-mugler.5096ca23.jpg"
  },
  {
    "revision": "3163d3a3b29257b2c699882508623887",
    "url": "/static/media/tizianaterenzi.3163d3a3.png"
  },
  {
    "revision": "351e4d760ef9ad454325989050aea4f1",
    "url": "/static/media/tom-ford-black-orchid-big.351e4d76.png"
  },
  {
    "revision": "ddf81e08599034626a234fad6cb7804c",
    "url": "/static/media/tom-ford-black-orchid-velvet.ddf81e08.png"
  },
  {
    "revision": "960c6d13fca298f846f59f9713068b00",
    "url": "/static/media/tom-ford-fucking-fabulous-big.960c6d13.png"
  },
  {
    "revision": "03330b91230c0bd190b646d9081f1193",
    "url": "/static/media/tom-ford-noir-big.03330b91.png"
  },
  {
    "revision": "0480ea692f65fa2a67d424c6611bac9b",
    "url": "/static/media/tom-ford-noir-extreme-big.0480ea69.png"
  },
  {
    "revision": "211a93cae20ac48e2ac886e8fea2f114",
    "url": "/static/media/tom-ford-ombre-leather-big.211a93ca.png"
  },
  {
    "revision": "b1c97d985875b6cb50d46b45138b6e1b",
    "url": "/static/media/tom-ford-tobacco-vanille-big.b1c97d98.png"
  },
  {
    "revision": "2a6daf188c6faca4711f68f139e243d0",
    "url": "/static/media/tom-ford.2a6daf18.jpg"
  },
  {
    "revision": "434349e51bba51d9907a38134ab706a1",
    "url": "/static/media/trussardi-donna.434349e5.png"
  },
  {
    "revision": "3bc2b38dcffd0f19de03f9ec75e3790b",
    "url": "/static/media/trussardi-uomo.3bc2b38d.png"
  },
  {
    "revision": "614d09018b2dd0e32ff1fc465f5bc5f1",
    "url": "/static/media/valentino-umo-big.614d0901.png"
  },
  {
    "revision": "3810856f9b84b66e4a99d4eab29eecb2",
    "url": "/static/media/valentino.3810856f.jpg"
  },
  {
    "revision": "048af5f59a195b3a3041a2fda3733f1d",
    "url": "/static/media/versace-bright-crystal-big.048af5f5.png"
  },
  {
    "revision": "5b202c03191916fc0e6c62f69b1092e9",
    "url": "/static/media/versace-crystal-noir-big.5b202c03.png"
  },
  {
    "revision": "08055678dea1d285c6bbe01cd2720fc1",
    "url": "/static/media/versace-dylan-blue-big.08055678.png"
  },
  {
    "revision": "969d4484e848f83c04f9f1224ae6abc2",
    "url": "/static/media/versace-eau-fraiche-man-big.969d4484.png"
  },
  {
    "revision": "9d4968f2ede8a5c32557827b9987f166",
    "url": "/static/media/versace-eros-big.9d4968f2.png"
  },
  {
    "revision": "0171078a72f7a2b62c5f1a8f5f96dfe4",
    "url": "/static/media/versace-eros-pour-femme-big.0171078a.png"
  },
  {
    "revision": "120a3d14f1dfbb7fef2b3aaf2f80416a",
    "url": "/static/media/versace-flame-big.120a3d14.png"
  },
  {
    "revision": "b93d9382a464ff9e42bf5390b351f5d5",
    "url": "/static/media/versace.b93d9382.jpg"
  },
  {
    "revision": "015024ff226a296466922536d9ea80b9",
    "url": "/static/media/women-preview.015024ff.jpg"
  },
  {
    "revision": "6d3eb453b4966e227d3800c55ea470c3",
    "url": "/static/media/ysl.6d3eb453.jpg"
  },
  {
    "revision": "c002d704402cf5cc4c6accca8deef573",
    "url": "/static/media/ysllibre.c002d704.png"
  },
  {
    "revision": "0d3c0ea91ef6c8bd45c8650bed5c03b5",
    "url": "/static/media/yves-saint-laurent-black-opium-big.0d3c0ea9.png"
  },
  {
    "revision": "ef40caa9f9188a4a352db64c96248f80",
    "url": "/static/media/yves-saint-laurent-kouros-big.ef40caa9.png"
  },
  {
    "revision": "00e308be5a8ba1d1c68cc2fd915e5290",
    "url": "/static/media/yves-saint-laurent-libre-big.00e308be.png"
  },
  {
    "revision": "852795f52ac67b83c71fafa418bed17f",
    "url": "/static/media/yves-saint-laurent-manifesto-big.852795f5.png"
  },
  {
    "revision": "91eb7c33d719d981048199eb4dbba77d",
    "url": "/static/media/yves-saint-laurent-y-by-ysl-big.91eb7c33.png"
  },
  {
    "revision": "b3942ae07690a41d19d74110cf3e4f9f",
    "url": "/static/media/yves-saint-lhomme-parfum-intentse-big.b3942ae0.jpg"
  },
  {
    "revision": "c92b74e6dfbd6aac7e370bd99a28e0a2",
    "url": "/static/media/yves-saint-lhomme-parfum-intentse-big.c92b74e6.png"
  }
]);